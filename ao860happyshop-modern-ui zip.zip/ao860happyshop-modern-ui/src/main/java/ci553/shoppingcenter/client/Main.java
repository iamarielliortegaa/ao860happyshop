package ci553.shoppingcenter.client;


/**
 * Simplified launcher for the modernized Shopping Center UI.
 */
public class
Main {
    public static void main(String[] args) {
        // Launch the unified JavaFX ShoppingCenterView
        ShoppingCenterView.main(args);
    }
}