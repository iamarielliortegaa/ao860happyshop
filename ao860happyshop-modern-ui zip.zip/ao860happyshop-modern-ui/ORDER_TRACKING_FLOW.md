# 📊 Order Tracking Flow Diagram

## Complete Order Placement and Tracking Flow

```
┌─────────────────────────────────────────────────────────────────────┐
│                    CUSTOMER JOURNEY                                  │
└─────────────────────────────────────────────────────────────────────┘

1. SHOPPING PHASE
   ┌──────────────┐
   │ Browse Shop  │
   │ - 30 Products│
   │ - Search     │
   │ - Filter     │
   │ - Sort       │
   └──────┬───────┘
          │
          ▼
   ┌──────────────┐
   │ Add to Cart  │
   │ - Select qty │
   │ - Check stock│
   └──────┬───────┘
          │
          ▼

2. CHECKOUT PHASE
   ┌───────────────────────┐
   │ 🛒 Shopping Cart      │
   │ - Review items        │
   │ - Update quantities   │
   │ - Apply discount      │
   │ - View total          │
   └──────┬────────────────┘
          │
          ▼
   ┌───────────────────────┐
   │ Proceed to Checkout   │
   └──────┬────────────────┘
          │
          ▼

3. SHIPPING PHASE ✨ NEW
   ┌───────────────────────────────┐
   │ 📦 Shipping Information       │
   │                               │
   │ ✓ Street Address (Required)  │
   │ ✓ City (Required)            │
   │ ✓ Postal Code (Required)     │
   │ ✓ Country (Required)         │
   │                               │
   │ [Validation Checks]           │
   │  - All fields filled          │
   │  - Valid format               │
   └──────┬────────────────────────┘
          │
          ▼
   ┌───────────────────────┐
   │ Continue to Payment   │
   └──────┬────────────────┘
          │
          ▼

4. PAYMENT PHASE
   ┌───────────────────────┐
   │ 💳 Payment Simulation │
   │ - Card number         │
   │ - Name                │
   │ - Expiry              │
   │ - CVV                 │
   └──────┬────────────────┘
          │
          ▼
   ┌───────────────────────┐
   │ Process Payment       │
   └──────┬────────────────┘
          │
          ▼

5. ORDER CREATION PHASE ✨ NEW
   ┌───────────────────────────────────────┐
   │ Create Order in Tracking System       │
   │                                       │
   │ Order ID: ORD-[timestamp]             │
   │ Status: ORDER_PLACED                  │
   │ Shipping: [address, postal, city]     │
   │ Estimated Delivery: +5 days           │
   │                                       │
   │ Actions:                              │
   │  ✓ Save to orders.csv                │
   │  ✓ Generate invoice                  │
   │  ✓ Update stock                      │
   │  ✓ Clear cart                         │
   └──────┬────────────────────────────────┘
          │
          ▼
   ┌───────────────────────┐
   │ Show Receipt          │
   │ - Order ID            │
   │ - Items               │
   │ - Shipping Info       │
   │ - Total               │
   │ - Delivery Date       │
   └──────┬────────────────┘
          │
          ▼

6. TRACKING PHASE ✨ NEW
   ┌───────────────────────────────────────────────────────┐
   │ 👤 Profile → My Orders                                │
   │                                                       │
   │ ┌───────────────────────────────────────────────┐   │
   │ │ Order #ORD-123456789    [🟣 Processing]      │   │
   │ ├───────────────────────────────────────────────┤   │
   │ │ 📍 123 Main St...London, SW1A 1AA            │   │
   │ │ 📅 Estimated: January 16, 2026               │   │
   │ │                                               │   │
   │ │ PROGRESS TRACKER:                             │   │
   │ │ [●]━━[●]━━[○]━━[○]━━[○]━━[○]                 │   │
   │ │ Order Process Ship Transit Out Deliver       │   │
   │ │ Placed  ing                for                │   │
   │ │                                               │   │
   │ │ [View Details]  [⏭️ Advance Status] (Admin) │   │
   │ └───────────────────────────────────────────────┘   │
   └───────────────────────────────────────────────────────┘

7. ORDER STATUS PROGRESSION ✨ NEW
   
   Stage 1: ORDER_PLACED 🟣
   ┌────────────────────────┐
   │ ● Order received       │
   │ Est. Delivery: +5 days │
   │ Status: Purple         │
   └──────┬─────────────────┘
          │ Admin advances
          ▼
   Stage 2: PROCESSING 🟠
   ┌────────────────────────┐
   │ ● Preparing order      │
   │ Est. Delivery: +4 days │
   │ Status: Orange         │
   └──────┬─────────────────┘
          │ Admin advances
          ▼
   Stage 3: SHIPPED 🔵
   ┌────────────────────────┐
   │ ● Package shipped      │
   │ Est. Delivery: +3 days │
   │ Status: Blue           │
   └──────┬─────────────────┘
          │ Admin advances
          ▼
   Stage 4: IN_TRANSIT 🔵
   ┌────────────────────────┐
   │ ● En route             │
   │ Est. Delivery: +2 days │
   │ Status: Blue           │
   └──────┬─────────────────┘
          │ Admin advances
          ▼
   Stage 5: OUT_FOR_DELIVERY 🟠
   ┌────────────────────────┐
   │ ● Out for delivery     │
   │ Est. Delivery: +1 day  │
   │ Status: Orange         │
   └──────┬─────────────────┘
          │ Admin advances
          ▼
   Stage 6: DELIVERED 🟢
   ┌────────────────────────┐
   │ ✅ Delivered!          │
   │ Actual Date: Today     │
   │ Status: Green          │
   └────────────────────────┘


┌─────────────────────────────────────────────────────────────────────┐
│                    DATA FLOW                                         │
└─────────────────────────────────────────────────────────────────────┘

[User Input] ━━━━━┓
                   ┃
[Cart Data]  ━━━━━╋━━━━━> [OrderTrackingService]
                   ┃              │
[Shipping Info] ━━┛              │
                                  ▼
                          ┌──────────────┐
                          │ Create Order │
                          │ - Generate ID│
                          │ - Set status │
                          │ - Calc dates │
                          └──────┬───────┘
                                 │
                    ┌────────────┼────────────┐
                    ▼            ▼            ▼
              [orders.csv]  [Invoice]  [Receipt]
                    │
                    │ Persist
                    ▼
         ┌──────────────────────┐
         │ Load on app start    │
         │ Display in Profile   │
         │ Track status changes │
         └──────────────────────┘


┌─────────────────────────────────────────────────────────────────────┐
│                    ADMIN WORKFLOW                                    │
└─────────────────────────────────────────────────────────────────────┘

1. Login as Admin
   │
   ▼
2. View All Orders
   │
   ▼
3. Select Order
   │
   ▼
4. Click "⏭️ Advance Status"
   │
   ▼
5. Status Updated:
   ┌─────────────────────────┐
   │ • Status changes        │
   │ • Date recalculated     │
   │ • Data persisted        │
   │ • UI refreshes          │
   │ • Toast notification    │
   └─────────────────────────┘
   │
   ▼
6. Repeat until DELIVERED


┌─────────────────────────────────────────────────────────────────────┐
│                    VISUAL COMPONENTS                                 │
└─────────────────────────────────────────────────────────────────────┘

ORDER CARD ANATOMY:
┌──────────────────────────────────────────┐
│ HEADER                                   │
│ ┌────────────────────────────────────┐  │
│ │ Order #ID        [Status Badge]    │  │
│ └────────────────────────────────────┘  │
│                                          │
│ INFO SECTION                             │
│ ┌────────────────────────────────────┐  │
│ │ 📍 Masked Address                  │  │
│ │ 📅 Estimated Delivery Date         │  │
│ └────────────────────────────────────┘  │
│                                          │
│ PROGRESS TRACKER                         │
│ ┌────────────────────────────────────┐  │
│ │ [●]━[●]━[○]━[○]━[○]━[○]           │  │
│ │  1   2   3   4   5   6             │  │
│ └────────────────────────────────────┘  │
│                                          │
│ ACTIONS                                  │
│ ┌────────────────────────────────────┐  │
│ │ [View Details] [Advance] (Admin)   │  │
│ └────────────────────────────────────┘  │
└──────────────────────────────────────────┘

PROGRESS CIRCLE STATES:
● Filled (Completed) - Purple fill, bold label
○ Empty (Pending)    - Gray border, muted label
━ Connector          - Purple if completed, gray if pending


┌─────────────────────────────────────────────────────────────────────┐
│                    HEADER BUTTONS                                    │
└─────────────────────────────────────────────────────────────────────┘

OLD (Before Fix):
[○]  [○]  [Login]  [Cart]  [Tracker]  [Dark]
 ↑    ↑
gray  gray
no    no
label label

NEW (After Fix):
[👤 Profile] [🔔 Notifications] [🔑 Login] [🛒 Cart (3)]
[📦 Orders] [🌙 Dark]

All buttons:
✓ Purple background (#7c4dff)
✓ Clear labels with emojis
✓ Bold text
✓ Visible and prominent
✓ Hover effects


┌─────────────────────────────────────────────────────────────────────┐
│                    KEY FEATURES SUMMARY                              │
└─────────────────────────────────────────────────────────────────────┘

✅ SHIPPING
   • Required address fields
   • Validation on all inputs
   • Default country selection
   • Clean, modern dialog

✅ TRACKING
   • 6-stage status system
   • Visual progress timeline
   • Color-coded badges
   • Multiple order support
   • Admin advancement
   • Real-time updates

✅ PERSISTENCE
   • CSV storage (orders.csv)
   • Auto-save on changes
   • Load on startup
   • Invoice generation

✅ UI/UX
   • Purple visible buttons
   • Clear labels and icons
   • Responsive design
   • Professional styling
   • Toast notifications

✅ INTEGRATION
   • Seamless checkout flow
   • Profile page integration
   • Admin controls
   • Data synchronization


┌─────────────────────────────────────────────────────────────────────┐
│                    FILE STRUCTURE                                    │
└─────────────────────────────────────────────────────────────────────┘

data/
├── products.csv (30 products)
└── orders.csv   (tracking data) ✨ NEW

src/main/java/ci553/shoppingcenter/
├── model/
│   └── Order.java (enhanced) ✨ UPDATED
├── service/
│   ├── OrderTrackingService.java ✨ NEW
│   ├── CartService.java (updated)
│   └── [other services...]
└── client/
    └── ShoppingCenterView.java (enhanced) ✨ UPDATED

src/main/resources/
└── shopping-center-styles.css (header buttons) ✨ UPDATED

Documentation:
├── QUICK_START.md
├── IMPLEMENTATION_SUMMARY.md
├── ORDER_TRACKING_IMPLEMENTATION.md ✨ NEW
├── VISUAL_FEATURES.md
├── FINAL_IMPLEMENTATION_SUMMARY.md ✨ NEW
└── ORDER_TRACKING_FLOW.md (this file) ✨ NEW


════════════════════════════════════════════════════════════════════
                    IMPLEMENTATION COMPLETE! ✨
════════════════════════════════════════════════════════════════════

All requirements met:
✓ Purple, visible, labeled header buttons
✓ Complete shipping information collection
✓ 6-stage order tracking system
✓ Visual progress indicators
✓ Multiple order support
✓ Admin order advancement
✓ Full integration with checkout
✓ Data persistence

Ready to use! 🚀
```

