// Archived legacy launcher - now delegates to the modern JavaFX launcher
public class Main {
    public static void main(String[] args) {
        // Delegate to the modernized launcher in the application package
        ci553.shoppingcenter.client.Main.main(args);
    }
}
