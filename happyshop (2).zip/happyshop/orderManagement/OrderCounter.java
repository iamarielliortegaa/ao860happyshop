package ci553.happyshop.orderManagement;

import ci553.happyshop.utility.StorageLocation;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * OrderCounter is responsible for generating unique, sequential orderIDs for new orders.
 *
 * <p>This class manages a persistent counter stored in an external text file:(ie,"orders/orderCounter.txt").
 * On first use, it creates the file and starts the counter at 1.
 * For subsequent calls, it reads the current number, increments it by 1, writes the updated value
 * back to the file, and returns the new order ID.</p>
 *
 * <p>File access is synchronized using a file lock to ensure safe operation in a multi-threaded
 * or multi-process environment. The method is simple to use by OrderHub
 * or any component that needs to generate order numbers.</p>
 *
 * <p>FileChannel allows exclusive locking of files or specific regions of files,
 * which prevents other threads or processes from accessing the file simultaneously,
 * ensuring data integrity. </p>
 *
 * <p> ByteBuffer allows you to work with raw byte data efficiently.
 * It interacts directly with FileChannel for reading and writing,
 * making file access faster and more flexible than traditional streams.</p>
 */

/**
 * OrderCounter is responsible for generating unique, sequential orderIDs for new orders.
 * Enhanced for robust error handling and logging.
 */
public class OrderCounter {
    private static final Logger logger = Logger.getLogger(OrderCounter.class.getName());

    /**
     * Generates a unique order ID by incrementing the value in the persistent counter file.
     * Uses file locking for thread/process safety and logs actions/errors.
     * @return new unique order ID
     * @throws IOException if file access fails
     */
    public static int generateOrderId() throws IOException {
        Path path = StorageLocation.orderCounterPath;
        try (FileChannel channel = FileChannel.open(path, StandardOpenOption.READ, StandardOpenOption.WRITE);
             FileLock lock = channel.lock()) {
            ByteBuffer buffer = ByteBuffer.allocate((int) channel.size());
            channel.read(buffer);
            buffer.flip();
            String content = new String(buffer.array()).trim();
            int currentId = Integer.parseInt(content);
            int newId = currentId + 1;
            channel.position(0);
            channel.truncate(0);
            channel.write(ByteBuffer.wrap(String.valueOf(newId).getBytes()));
            logger.info("OrderId generated: " + newId);
            return newId;
        } catch (IOException | NumberFormatException e) {
            logger.log(Level.SEVERE, "Failed to generate order ID", e);
            throw e;
        }
    }
    }
}
