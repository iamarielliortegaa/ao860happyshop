package ci553.happyshop.catalogue;

import java.util.Objects;

/**
 * The Product class used to hold the information about a product:
 *
 * Fields:
 * - productId: Unique identifier for the product (eg 0001).
 * - description: Textual description of the product.
 * - unitPrice: Price per single unit of the product.
 * - orderedQuantity: Quantity involved in a customer's order.
 * - stockQuantity: Quantity currently available in stock.
 */

public class Product implements Comparable<Product> {
    private final String proId;
    private final String proDescription;
    private final String proImageName;
    private final double unitPrice;
    private int orderedQuantity = 1; // The quantity of this product in the customer's order.
    private int stockQuantity;

    /**
     * Constructor,used by DatabaseRW, make product from searching ResultSet
     * @param id Product ID
     * @param des Description of product
     * @param image image name of product, eg 0001.jpg (0001 is product ID)
     * @param aPrice The price of the product
     * @param stockQuantity The Quantity of the product in stock
     */
    public Product(String id, String des, String image, double aPrice, int stockQuantity) {
        if (id == null || id.isEmpty()) throw new IllegalArgumentException("Product ID cannot be null or empty");
        if (des == null || des.isEmpty()) throw new IllegalArgumentException("Description cannot be null or empty");
        if (image == null || image.isEmpty()) throw new IllegalArgumentException("Image name cannot be null or empty");
        if (aPrice < 0) throw new IllegalArgumentException("Unit price cannot be negative");
        if (stockQuantity < 0) throw new IllegalArgumentException("Stock quantity cannot be negative");
        this.proId = id;
        this.proDescription = des;
        this.proImageName = image;
        this.unitPrice = aPrice;
        this.stockQuantity = stockQuantity;
    }

    // a set of getter methods
    public String getProductId() { return proId; }
    public String getProductDescription() { return proDescription; }
    public String getProductImageName() { return proImageName; }
    public double getUnitPrice() { return unitPrice; }
    public int getOrderedQuantity() { return orderedQuantity; }
    public int getStockQuantity() { return stockQuantity; }

    /**
     * Sets the ordered quantity for this product in the customer's order.
     * @param orderedQuantity Quantity ordered (must be positive)
     */
    public void setOrderedQuantity(int orderedQuantity) {
        if (orderedQuantity < 1) throw new IllegalArgumentException("Ordered quantity must be at least 1");
        this.orderedQuantity = orderedQuantity;
    }

    /**
     * Updates the stock quantity for this product.
     * @param stockQuantity New stock quantity (must be non-negative)
     */
    public void setStockQuantity(int stockQuantity) {
        if (stockQuantity < 0) throw new IllegalArgumentException("Stock quantity cannot be negative");
        this.stockQuantity = stockQuantity;
    }

    @Override
    public int compareTo(Product otherProduct) {
        // Compare by product ID or any other attribute you want to sort by
        return this.proId.compareTo(otherProduct.proId); // Sort by proId alphabetically (ascending)
    }

    @Override
    // Creates a formatted string containing ID, price (with 2 decimal places), stock amount, and description
    // Used in the Warehouse search page to display searched product information
    public String toString() {
        return String.format("Id: %s, £%.2f/unit, stock: %d\n%s",
                proId, unitPrice, stockQuantity, proDescription);
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Product product = (Product) o;
        return Double.compare(product.unitPrice, unitPrice) == 0 &&
                orderedQuantity == product.orderedQuantity &&
                stockQuantity == product.stockQuantity &&
                proId.equals(product.proId) &&
                proDescription.equals(product.proDescription) &&
                proImageName.equals(product.proImageName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(proId, proDescription, proImageName, unitPrice, orderedQuantity, stockQuantity);
    }

    // Alternative constructors can be added as needed for future use, but should follow validation best practices.

}

