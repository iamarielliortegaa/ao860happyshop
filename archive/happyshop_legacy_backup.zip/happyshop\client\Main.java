package ci553.happyshop.client;

import ci553.happyshop.client.shoppingcenter.ShoppingCenterView;

/**
 * Main Application Launcher - Modernized Shopping Center
 * Launches ONLY the unified Shopping Center interface (JavaFX)
 * All old clients have been removed
 *
 * @version 4.0 - Fully Modernized
 * @author Arielli Ortega, University of Brighton
 */
public class Main {

    public static void main(String[] args) {
        // Delegate to JavaFX application
        ShoppingCenterView.main(args);
    }
}